package com.practice.tv_player;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.alphamovie.lib.AlphaMovieView;

public class alpha_movie extends AppCompatActivity {
   // public static final String FILENAME = "raw/ball.mp4";

    public static final int FIRST_BG_INDEX = 0;
    public static final int BG_ARRAY_LENGTH = 3;

    public static final int[] backgroundResources = new int[]{R.drawable.court_blue,
            R.drawable.court_green, R.drawable.court_red};

    private AlphaMovieView alphaMovieView;

    private ImageView imageViewBackground;
    private int bgIndex = FIRST_BG_INDEX;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alpha_movie);

        imageViewBackground = (ImageView) findViewById(R.id.image_background);

        alphaMovieView = (AlphaMovieView) findViewById(R.id.video_player);
        alphaMovieView.setVideoByUrl("http://techslides.com/demos/sample-videos/small.mp4");
    }

    @Override
    public void onResume() {
        super.onResume();
        alphaMovieView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        alphaMovieView.onPause();
    }

    public void play(View view) {
        alphaMovieView.start();
    }

    public void pause(View view) {
        alphaMovieView.pause();
    }

    public void stop(View view) {
        alphaMovieView.stop();
    }

    public void changeBackground(View view) {
        bgIndex = ++bgIndex % BG_ARRAY_LENGTH;
        imageViewBackground.setImageResource(backgroundResources[bgIndex]);
    }
}