package com.practice.tv_player;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.videoviewholder> {

    private ArrayList<VideoModal> getVideo;
    private Context context;
    private videoClickinterface videoClickinterface;

    public VideoAdapter(ArrayList<VideoModal> getVideo, Context context , videoClickinterface videoClickinterface)
    {
        this.getVideo = getVideo;
        this.context = context;
        this.videoClickinterface = videoClickinterface;
    }

    @NonNull
    @Override
    public videoviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_video,parent,false);

        return new videoviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull videoviewholder holder, @SuppressLint("RecyclerView") int position) {
        VideoModal videoModal = getVideo.get(position);

        holder.thumbnail.setImageBitmap(videoModal.getThumbnail());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoClickinterface.onVideoclick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return getVideo.size();
    }

    public class videoviewholder extends RecyclerView.ViewHolder {
        ImageView thumbnail;

        public videoviewholder(@NonNull View itemView) {
            super(itemView);
            thumbnail = (ImageView) itemView.findViewById(R.id.ivthumbnail);
        }
    }

    public interface videoClickinterface
    {
        void onVideoclick(int position1);
    }
}
