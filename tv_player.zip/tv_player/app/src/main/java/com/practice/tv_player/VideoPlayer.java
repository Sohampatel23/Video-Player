package com.practice.tv_player;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SubtitleData;
import android.media.TimedText;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Rational;
import android.view.Display;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.avery.subtitle.widget.SimpleSubtitleView;
import com.lukelorusso.verticalseekbar.VerticalSeekBar;
import com.practice.tv_player.ViewModel.VideoModel;
import com.practice.tv_player.ViewModel.ViewModelFactory;
import com.practice.tv_player.databinding.ActivityVideoPlayerBinding;

import java.io.IOException;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import sh.casey.subtitler.model.SubtitleFile;
import sh.casey.subtitler.model.SubtitleType;
import sh.casey.subtitler.reader.SubtitleReader;
import sh.casey.subtitler.reader.SubtitleReaderFactory;

public class VideoPlayer extends AppCompatActivity
//        implements View.OnTouchListener, ScaleGestureDetector.OnScaleGestureListener
{
    TextView videonameTV, videotimeTV,totaltime,subtitle;
    // SimpleSubtitleView ;
    ImageView backib,forwardib,close,picin,cast;
    ImageButton playib;
    ImageView fullscreen, exitscreen;
    SeekBar videoseekbar;
    VerticalSeekBar brightness,volume;
    VideoView videoView;
    Display display;
    Point size;
    RelativeLayout rlcontrol,rlvideo;
    LinearLayout brightlayout,volumelayout;
    private PictureInPictureParams.Builder pictureInPictureParams;

    String SUBTITLE_URL = "assets/movie.srt";
    boolean isopen = true;
    boolean intleft,intright,brightbool,volumebool;
    String videoname,videopath;
    int swidth;
    long diffX, diffY;
    private static final float MIN_ZOOM = 1.0f;
    private static final float MAX_ZOOM = 5.0f;
    private static final int SWIPE_MIN_DISTANCE = 6;
    private static final int SWIPE_MAX_OFF_PATH = 125;
    private static final int SWIPE_THRESHOLD_VELOCITY = 100;

    private static final int MIN_DISTANCE = 150;
    private static final String TAG = "swipe position";
    private float x1,x2,y1,y2;

    private Mode mode = Mode.NONE;
    private enum Mode {
        NONE,
        DRAG,
        ZOOM;
    }
    float scale = 1.0f;
    float lastScaleFactor = 0f;

    float startX = 0f;
    float startY = 0f;

    float dx = 0f;
    float dy = 0f;
    float prevDx = 0f;
    float prevDy = 0f;
    int device_width;
    int bright,currentb;

    int volumeLevel;
    AudioManager audioManager;

    GestureDetectorCompat gestureDetectorCompat;
    ScaleGestureDetector scaleGestureDetector;

    ActivityVideoPlayerBinding binding;/*doing this is not databinging ;this is viewbinding*/
    VideoModel viewModel;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_video_player);
        binding = DataBindingUtil.setContentView(VideoPlayer.this, R.layout.activity_video_player);
        viewModel = new ViewModelProvider(VideoPlayer.this, new ViewModelFactory<>(this, binding)).get(VideoModel.class);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

//        videonameTV = findViewById(R.id.tvvideotitle);
//        videotimeTV = findViewById(R.id.tvtime);
//        totaltime = findViewById(R.id.tvtotaltime);
//        subtitle = findViewById(R.id.tv_subtitle);
//        backib = findViewById(R.id.ibback);
//        forwardib = findViewById(R.id.ibforward);
//        playib = findViewById(R.id.ibplay);
//        videoseekbar = findViewById(R.id.seekbarprogress);
//        videoView = findViewById(R.id.videoview);
//        rlcontrol = findViewById(R.id.rlcontrols);
//        rlvideo = findViewById(R.id.rlvideo);
//        fullscreen = findViewById(R.id.fullscreen);
//        exitscreen = findViewById(R.id.fullscreenexit);
//        brightness = findViewById(R.id.seek_brightness);
//        volume = findViewById(R.id.seek_volume);
//        brightlayout = findViewById(R.id.bright_layout);
//        volumelayout = findViewById(R.id.volume_layout);
//        picin = findViewById(R.id.ivpic);
//        close = findViewById(R.id.ivclose);
//        cast = findViewById(R.id.ivcast);
//
//
//
//        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
//        volume.setMaxValue(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
//        volumeLevel = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
//        volume.setProgress(volumeLevel);
//
//        volume.setOnProgressChangeListener(new Function1<Integer, Unit>() {
//            @Override
//            public Unit invoke(Integer integer) {
//                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, integer, 0);
//                return null;
//            }
//        });
//
//        close.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                finish();
//            }
//        });
//
//        cast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                try {
//                    startActivity(new Intent("android.settings.WIFI_DISPLAY_SETTINGS"));
//                } catch (ActivityNotFoundException e) {
//                    e.printStackTrace();
//                    try {
//                        startActivity(new Intent("com.samsung.wfd.LAUNCH_WFD_PICKER_DLG"));
//                    } catch (Exception e2) {
//                        try {
//                            startActivity(new Intent("android.settings.CAST_SETTINGS"));
//                        } catch (Exception e3) {
//                            Toast.makeText(getApplicationContext(), "Device not supported", Toast.LENGTH_LONG).show();
//                        }
//                    }
//                }
//            }
//        });
//
//        bright = Settings.System.getInt(getContentResolver(),
//                        Settings.System.SCREEN_BRIGHTNESS, 0);
//        brightness.setProgress(bright);
//        brightness.setOnProgressChangeListener(new Function1<Integer, Unit>() {
//            @Override
//            public Unit invoke(Integer integer) {
////                Settings.System.putInt(getContentResolver(),
////                        Settings.System.SCREEN_BRIGHTNESS, integer);
//
//                float BackLightValue = (float)integer/100;
//
//                WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
//                layoutParams.screenBrightness = BackLightValue;
//                getWindow().setAttributes(layoutParams);
//                return null;
//            }
//        });
//
//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
//        {
//            pictureInPictureParams = new PictureInPictureParams.Builder();
//        }
//
//        picin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                pictureInPictureMode();
//            }
//        });
//
//        scaleGestureDetector = new ScaleGestureDetector(this,this);
//        gestureDetectorCompat = new GestureDetectorCompat(this, new GestureDetector());
//
//        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
//            @RequiresApi(api = Build.VERSION_CODES.P)
//            @Override
//            public void onPrepared(MediaPlayer mediaPlayer) {
//                videoseekbar.setMax(videoView.getDuration());
//                totaltime.setText(""+convertTime(videoView.getDuration()));
//                videoView.start();
//
//                SubtitleReaderFactory factory = new SubtitleReaderFactory();
//                SubtitleReader reader = factory.getInstance(SubtitleType.SRT);
//
//// This will be an SrtSubtitleFile under the hood.
//                SubtitleFile file = reader.read("/storage/emulated/0/Download/movie.srt");
//                System.out.println(file);
//            }
//        });
//
//        setVideoView(getIntent());
//
//
//
//        backib.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                videoView.seekTo(videoView.getCurrentPosition()-15000);
//            }
//        });
//
//        forwardib.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                videoView.seekTo(videoView.getCurrentPosition()+15000);
//            }
//        });
//
//        playib.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if(videoView.isPlaying())
//                {
//                    videoView.pause();
//                    playib.setImageResource(R.drawable.ic_play);
//                }
//                else
//                {
//                    videoView.start();
//                    playib.setImageResource(R.drawable.ic_pause);
//                }
//            }
//        });
//
//        display = getWindowManager().getDefaultDisplay();
//        size = new Point();
//        display.getSize(size);
//        swidth = size.x;
//        DisplayMetrics displayMetrics = new DisplayMetrics();
//        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//        device_width = displayMetrics.widthPixels;
//        rlvideo.setOnTouchListener(this);
//
//        fullscreen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//                exitscreen.setVisibility(View.VISIBLE);
//                fullscreen.setVisibility(View.GONE);
//            }
//        });
//
//        exitscreen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                exitscreen.setVisibility(View.GONE);
//                fullscreen.setVisibility(View.VISIBLE);
//
//                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
//            }
//        });
//
//        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
//        {
//            exitscreen.setVisibility(View.VISIBLE);
//            fullscreen.setVisibility(View.GONE);
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        }
//
//        Handler();
//        initializeSeekBar();
    }

    public void setVideoView(Intent intent) {
        videoname = intent.getStringExtra("videoname");
        videopath = intent.getStringExtra("videopath");

        videoView.setVideoURI(Uri.parse(videopath));

        videonameTV.setText(videoname);
    }

//    @Override
//    public boolean onScale(ScaleGestureDetector scaleDetector) {
//        scale *= scaleGestureDetector.getScaleFactor();
//        scale = Math.max(0.1f, Math.min(scale, 10.0f));
//        videoView.setScaleX(scale);
//        videoView.setScaleY(scale);
//        return true;
//    }
//
//    @Override
//    public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
//        return true;
//    }
//
//    @Override
//    public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {}
//
//    private class GestureDetector extends android.view.GestureDetector.SimpleOnGestureListener {
//        @Override
//        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
//            try{
//                if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
//                    return false;
//
//                if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//                    Toast.makeText(getApplicationContext(), "Left Swipe", Toast.LENGTH_SHORT).show();
//                    videoView.seekTo(videoView.getCurrentPosition() - 2000);
//
//
//                } else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//                    Toast.makeText(getApplicationContext(), "Right Swipe", Toast.LENGTH_SHORT).show();
//                    videoView.seekTo(videoView.getCurrentPosition() + 2000);
//
//                } else if (e1.getY() - e2.getY() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//                    Toast.makeText(getApplicationContext(), "Swipe up", Toast.LENGTH_SHORT).show();
//
//                } else if (e2.getY() - e1.getY() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//                    Toast.makeText(getApplicationContext(), "Swipe down", Toast.LENGTH_SHORT).show();
//                }
//            }catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//            return super.onFling(e1, e2, velocityX, velocityY);
//        }
//
//        @Override
//        public boolean onDoubleTap(MotionEvent event) {
//            if(event.getX() < (swidth / 2))
//            {
//                intleft = true;
//                intright = false;
//                videoView.seekTo(videoView.getCurrentPosition() - 20000);
//            }
//            else if(event.getX() > (swidth / 2))
//            {
//                intleft = false;
//                intright = true;
//                videoView.seekTo(videoView.getCurrentPosition() + 20000);
//            }
//            return super.onDoubleTap(event);
//        }
//
//        @Override
//        public boolean onSingleTapConfirmed(MotionEvent e) {
//            if(isopen)
//            {
//                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
//                volumelayout.setVisibility(View.GONE);
//                brightlayout.setVisibility(View.GONE);
//                hidecontrols();
//                isopen = false;
//            }
//            else
//            {
//                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
//                volumelayout.setVisibility(View.VISIBLE);
//                brightlayout.setVisibility(View.VISIBLE);
//                showcontrols();
//                isopen = true;
//            }
//            return super.onSingleTapConfirmed(e);
//        }
//    }
//
//    private void Handler() {
//        Handler handler = new Handler();
//        Runnable runnable = new Runnable() {
//            @Override
//            public void run() {
//                if(videoView.getDuration()>0)
//                {
//                    int curpos = videoView.getCurrentPosition();
//                    videoseekbar.setProgress(curpos);
//                    videotimeTV.setText(""+convertTime(videoView.getDuration()-curpos));
//                }
//                handler.postDelayed(this,0);
//            }
//        };
//        handler.postDelayed(runnable,500);
//    }
//
//    private String convertTime(int ms) {
//        String time;
//        int x,seconds,minutes,hours;
//        x = ms/1000;
//        seconds = x%60;
//        x /= 60;
//        minutes = x % 60;
//        x /= 60;
//        hours = x%24;
//        if(hours!=0)
//        {
//            time = String.format("%02d",hours)+":"+String.format("%02d",minutes)+":"+String.format("%02d",seconds);
//        }
//        else
//        {
//            time = String.format("%02d",minutes)+":"+String.format("%02d",seconds);
//        }
//        return time;
//    }
//
//    private void initializeSeekBar() {
//        videoseekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//            @Override
//            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
//                if(videoseekbar.getId()==R.id.seekbarprogress) {
//                    if(b) {
//                        videoView.seekTo(i);
//                        videoView.start();
//                        int curpos = videoView.getCurrentPosition();
//                        videotimeTV.setText(""+convertTime(videoView.getDuration()-curpos));
//                        playib.setImageResource(R.drawable.ic_pause);
//                    }
//                }
//            }
//            @Override
//            public void onStartTrackingTouch(SeekBar seekBar) {
//
//            }
//
//            @Override
//            public void onStopTrackingTouch(SeekBar seekBar) {
//
//            }
//        });
//    }
//
//    private void showcontrols() {
//        rlcontrol.setVisibility(View.VISIBLE);
//
//        final Window window = this.getWindow();
//        if(window==null)
//        {
//            return;
//        }
////        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
////        window.clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
//        View decorview = window.getDecorView();
//        if(decorview!=null)
//        {
//            int uioption = decorview.getSystemUiVisibility();
//            if(Build.VERSION.SDK_INT>=14)
//            {
//                uioption&= ~View.SYSTEM_UI_FLAG_LOW_PROFILE;
//            }
//
//            if(Build.VERSION.SDK_INT>=16)
//            {
//                uioption&= ~View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
//            }
//
//            if(Build.VERSION.SDK_INT>=19)
//            {
//                uioption&= ~View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
//            }
//            decorview.setSystemUiVisibility(uioption);
//        }
//    }
//
//    private void hidecontrols() {
//        rlcontrol.setVisibility(View.GONE);
//
//        if(volumebool == true)
//        {
//            volumelayout.setVisibility(View.VISIBLE);
//            brightlayout.setVisibility(View.GONE);
//        }
//        else
//        {
//            volumelayout.setVisibility(View.GONE);
//        }
//
//        if(brightbool == true)
//        {
//            brightlayout.setVisibility(View.VISIBLE);
//            volumelayout.setVisibility(View.GONE);
//        }
//        else
//        {
//            brightlayout.setVisibility(View.GONE);
//        }
//
//        final Window window = this.getWindow();
//        if(window==null)
//        {
//            return;
//        }
//
////        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
////        window.clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
//        View decorview = window.getDecorView();
//        if(decorview!=null)
//        {
//            int uioption = decorview.getSystemUiVisibility();
//            if(Build.VERSION.SDK_INT>=14)
//            {
//                uioption |= View.SYSTEM_UI_FLAG_LOW_PROFILE;
//            }
//
//            if(Build.VERSION.SDK_INT>=16)
//            {
//                uioption |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
//            }
//
//            if(Build.VERSION.SDK_INT>=19)
//            {
//                uioption |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
//            }
//            decorview.setSystemUiVisibility(uioption);
//        }
//    }
//
//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        scaleGestureDetector.onTouchEvent(event);
//        return super.onTouchEvent(event);
//    }
//
//    @Override
//    public boolean onTouch(View view, MotionEvent motionEvent) {
//        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK)
//        {
//            case MotionEvent.ACTION_DOWN:
//                x1 = motionEvent.getX();
//                y1 = motionEvent.getY();
//
//                hidecontrols();
//                if(scale > MIN_ZOOM) {
//                    mode = Mode.DRAG;
//                    startX = motionEvent.getX() - prevDx;
//                    startY = motionEvent.getY() - prevDy;
//                }
//                break;
//
//            case MotionEvent.ACTION_POINTER_DOWN:
//                mode = Mode.ZOOM;
//                break;
//            case MotionEvent.ACTION_POINTER_UP:
//                mode = Mode.DRAG;
//                break;
//            case MotionEvent.ACTION_UP:
//                x2 = motionEvent.getX();
//                y2 = motionEvent.getY();
//
//                float valueX = x2 - x1;
//                float valueY = y2 - y1;
//
//                if(Math.abs(valueX) > MIN_DISTANCE)
//                {
//                    if(x2>x1){
//                       // videoView.seekTo(videoView.getCurrentPosition() + 2000);
//                        Log.d("swipe","right swiped");
//                    }
//                    else{
//
//                        // 3videoView.seekTo(videoView.getCurrentPosition() - 2000);
//                        Log.d("swipe","left swiped");
//
//                    }
//                }
//                else if(Math.abs(valueY) > MIN_DISTANCE) {
//                    if (motionEvent.getX() > (swidth / 2)) {
//
//                        if (y2 > y1) {
//                            brightbool = true;
//                            hidecontrols();
//                            int f = brightness.getProgress();
//                            currentb = f - 30;
//
//                            float BackLightValue = (float) currentb / 100;
//
//                            WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
//                            layoutParams.screenBrightness = BackLightValue;
//                            getWindow().setAttributes(layoutParams);
//                            brightness.setProgress(currentb);
//
//                            Log.d("swipe", "down swiped");
//
//                            new Handler().postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    brightbool = false;
//                                    hidecontrols();
//                                }
//                            },1000);
//                        } else {
//                            brightbool = true;
//                            hidecontrols();
//                            int f = brightness.getProgress();
//                            currentb = f + 30;
//
//                            float BackLightValue = (float) currentb / 100;
//                            WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
//                            layoutParams.screenBrightness = BackLightValue;
//                            getWindow().setAttributes(layoutParams);
//                            brightness.setProgress(currentb);
//                            Log.d("swipe", "up swiped");
//
//                            new Handler().postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    brightbool = false;
//                                    hidecontrols();
//                                }
//                            },1000);
//                        }
//                    }
//
//                    else if(motionEvent.getX() < (swidth / 2))
//                    {
//                        if (y2 > y1) {
//                           volumebool = true;
//                           hidecontrols();
//                            int f = volume.getProgress();
//                            volumeLevel = f - 5;
//                            volume.setProgress(volumeLevel);
//                            Log.d("swipe", "down swiped");
//
//                            new Handler().postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    volumebool = false;
//                                    hidecontrols();
//                                }
//                            },1000);
//                        }
//                        else
//                        {
//                            volumebool = true;
//                            hidecontrols();
//                            int f = volume.getProgress();
//                            volumeLevel = f + 5;
//
//                            volume.setProgress(volumeLevel);
//                            Log.d("swipe", "down swiped");
//
//                            new Handler().postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    volumebool = false;
//                                    hidecontrols();
//                                }
//                            },1000);
//                        }
//                    }
//                    mode = Mode.NONE;
//                    prevDx = dx;
//                    prevDy = dy;
//                    break;
//                }
//        }
//        scaleGestureDetector.onTouchEvent(motionEvent);
//        gestureDetectorCompat.onTouchEvent(motionEvent);
//        brightness.onTouchEvent(motionEvent);
//        if ((mode == Mode.DRAG && scale >= MIN_ZOOM) || mode == Mode.ZOOM) {
//            rlvideo.requestDisallowInterceptTouchEvent(true);
//            float maxDx = (child().getWidth() - (child().getWidth() / scale)) / 2 * scale;
//            float maxDy = (child().getHeight() - (child().getHeight() / scale)) / 2 * scale;
//            dx = Math.min(Math.max(dx, -maxDx), maxDx);
//            dy = Math.min(Math.max(dy, -maxDy), maxDy);
//            applyScaleAndTranslation();
//        }
//        return true;
//    }
//
//    private View child() {
//        return zoomLayout(0);
//    }
//
//    private View zoomLayout(int i) {
//        return videoView;
//    }
//
//    private void applyScaleAndTranslation() {
//        child().setScaleX(scale);
//        child().setScaleY(scale);
//        child().setTranslationX(dx);
//        child().setTranslationY(dy);
//    }

    private void pictureInPictureMode() {

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {

            Rational aspectratio = new Rational(videoView.getWidth(),videoView.getHeight());
            pictureInPictureParams.setAspectRatio(aspectratio).build();
            enterPictureInPictureMode(pictureInPictureParams.build());
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
        {
            if(!isInPictureInPictureMode())
            {
                Log.e("pic","not in mode");
            }
            else{
                Log.e("pic","in mode");
            }
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        Log.e("mode",""+isInPictureInPictureMode);
        if(isInPictureInPictureMode)
        {
            //picin.setVisibility(View.GONE);
            viewModel.hidecontrols();
            rlcontrol.setVisibility(View.GONE);
            Log.e("pic","in mode1");
        }
        else {
            // picin.setVisibility(View.VISIBLE);
            viewModel.hidecontrols();
            Log.e("pic","not in mode1");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setVideoView(intent);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(videoView.isPlaying())
        {
            videoView.stopPlayback();
        }
    }
}