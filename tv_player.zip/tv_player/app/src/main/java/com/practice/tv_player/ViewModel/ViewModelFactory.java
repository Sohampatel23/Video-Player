package com.practice.tv_player.ViewModel;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class ViewModelFactory<T> implements ViewModelProvider.Factory {
    private Activity activity;
    private T binding;

    public ViewModelFactory(Activity activity, T binding) {
        this.activity = activity;
        this.binding = binding;
    }
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass == VideoModel.class) {
            return (T) new VideoModel(activity, binding);
        }
        return null;
    }
}
