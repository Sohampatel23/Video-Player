package com.practice.tv_player;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ProgressBar;

import java.util.ArrayList;

public class custom_videoplayer extends AppCompatActivity implements VideoAdapter.videoClickinterface{

    RecyclerView videolist;
    ProgressBar pb;
    public ArrayList<VideoModal> videoarraylist;
    public VideoAdapter videoAdapter;
    private static final int STORAGE_PERMISSION = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_videoplayer);
        videolist = findViewById(R.id.rvvideos);
        pb = findViewById(R.id.progressbar);

        pb.setVisibility(View.VISIBLE);
        videoarraylist = new ArrayList<>();
        videoAdapter = new VideoAdapter(videoarraylist,this,this::onVideoclick);
        videolist.setLayoutManager(new GridLayoutManager(this,2));
        videolist.setAdapter(videoAdapter);

        if(ContextCompat.checkSelfPermission(custom_videoplayer.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(custom_videoplayer.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},STORAGE_PERMISSION);
        }
        else
        {
            getVideos();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==STORAGE_PERMISSION)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                getVideos();
            }
            else
            {
                finish();
            }
        }
    }

    private void getVideos() {
        ContentResolver contentResolver = getContentResolver();
        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        Cursor cursor = contentResolver.query(uri,null,null,null,null);
        if(cursor!=null && cursor.moveToFirst())
        {
         //   for(int i=0;i<=10;i++)
            do{
                @SuppressLint("Range") String videoTitle = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.TITLE));
                @SuppressLint("Range") String videopath = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DATA));
                @SuppressLint("Range") Bitmap thumbnail = ThumbnailUtils.createVideoThumbnail(videopath,MediaStore.Images.Thumbnails.MINI_KIND);

                videoarraylist.add(new VideoModal(videoTitle,videopath,thumbnail));
                //cursor.moveToNext();
            }
            while (cursor.moveToNext());
        }
        videoAdapter.notifyDataSetChanged();
        pb.setVisibility(View.GONE);
    }

    @Override
    public void onVideoclick(int position1) {
        Intent im = new Intent(custom_videoplayer.this,ExoPlayer.class);
        im.putExtra("videoname",videoarraylist.get(position1).getVideoName());
        im.putExtra("videopath",videoarraylist.get(position1).getVideoPath());
        startActivity(im);
    }

}