package com.practice.tv_player;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Point;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Rational;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ConcatenatingMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;

import com.google.android.exoplayer2.ui.PlayerView;
import com.lukelorusso.verticalseekbar.VerticalSeekBar;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class ExoPlayer extends AppCompatActivity implements View.OnTouchListener, ScaleGestureDetector.OnScaleGestureListener {
    TextView videonameTV;
String videopath,videoname;
    ImageView close,picin,cast;
    ImageView fullscreen, exitscreen;
    VerticalSeekBar brightness,volume;
    RelativeLayout rlcontrol,rlvideo;
    AudioManager audioManager;
    ScaleGestureDetector scaleGestureDetector;
    GestureDetectorCompat gestureDetectorCompat;
    private PictureInPictureParams.Builder pictureInPictureParams;

    int volumeLevel,bright,swidth;
    boolean isopen = true;
    boolean intleft,intright,brightbool,volumebool;
    LinearLayout brightlayout,volumelayout;
    Point size;

    private static final float MIN_ZOOM = 1.0f;
    private static final float MAX_ZOOM = 5.0f;
    private static final int SWIPE_MIN_DISTANCE = 6;
    private static final int SWIPE_MAX_OFF_PATH = 125;
    private static final int SWIPE_THRESHOLD_VELOCITY = 100;

    private static final int MIN_DISTANCE = 150;
    private float x1,x2,y1,y2;
    float scale = 1.0f;
    private ExoPlayer.Mode mode = ExoPlayer.Mode.NONE;
    private enum Mode {
        NONE,
        DRAG,
        ZOOM;
    }

    float ScaleFactor = 1.0f;
    float startX = 0f;
    float startY = 0f;
    Display display;
    float dx = 0f;
    float dy = 0f;
    float prevDx = 0f;
    float prevDy = 0f;
    int currentb,device_width;
    PlayerView playerView;
    SimpleExoPlayer exoPlayer;

    ConcatenatingMediaSource concatenatingMediaSource;
    public static DefaultTrackSelector trackSelector;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exo_player);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        videonameTV = findViewById(R.id.tvvideotitle);
        rlcontrol = findViewById(R.id.excontrols);
        rlvideo = findViewById(R.id.rlvideoexo);
        fullscreen = findViewById(R.id.fullscreen);
        exitscreen = findViewById(R.id.fullscreenexit);
        picin = findViewById(R.id.ivpic);
        close = findViewById(R.id.ivclose);
        cast = findViewById(R.id.ivcast);
        brightness = findViewById(R.id.seek_brightness);
        volume = findViewById(R.id.seek_volume);
        brightlayout = findViewById(R.id.bright_layout);
        volumelayout = findViewById(R.id.volume_layout);

       exoPlayer = new SimpleExoPlayer.Builder(this).build();

        playerView = findViewById(R.id.exoplayer);
        playerView.setPlayer(exoPlayer);

        playerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction() & MotionEvent.ACTION_MASK)
                {
                    case MotionEvent.ACTION_DOWN:
                        x1 = motionEvent.getX();
                        y1 = motionEvent.getY();

                        hidecontrols();
                        if(scale > MIN_ZOOM) {
                            mode = ExoPlayer.Mode.DRAG;
                            startX = motionEvent.getX() - prevDx;
                            startY = motionEvent.getY() - prevDy;
                        }
                        break;

                    case MotionEvent.ACTION_POINTER_DOWN:
                        mode = ExoPlayer.Mode.ZOOM;
                        break;
                    case MotionEvent.ACTION_POINTER_UP:
                        mode = ExoPlayer.Mode.DRAG;
                        break;
                    case MotionEvent.ACTION_UP:
                        x2 = motionEvent.getX();
                        y2 = motionEvent.getY();

                        float valueX = x2 - x1;
                        float valueY = y2 - y1;

                        if(Math.abs(valueX) > MIN_DISTANCE)
                        {
                            if(x2>x1){
                                // videoView.seekTo(videoView.getCurrentPosition() + 2000);
                                Log.d("swipe","right swiped");
                            }
                            else{

                                // 3videoView.seekTo(videoView.getCurrentPosition() - 2000);
                                Log.d("swipe","left swiped");

                            }
                        }
                        else if(Math.abs(valueY) > MIN_DISTANCE) {
                            if (motionEvent.getX() > (swidth / 2)) {

                                if (y2 > y1) {
                                    brightbool = true;
                                    hidecontrols();
                                    int f = brightness.getProgress();
                                    currentb = f - 30;

                                    float BackLightValue = (float) currentb / 100;

                                    WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                                    layoutParams.screenBrightness = BackLightValue;
                                    getWindow().setAttributes(layoutParams);
                                    brightness.setProgress(currentb);

                                    Log.d("swipe", "down swiped");

                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            brightbool = false;
                                            hidecontrols();
                                        }
                                    },1000);
                                } else {
                                    brightbool = true;
                                    hidecontrols();
                                    int f = brightness.getProgress();
                                    currentb = f + 30;

                                    float BackLightValue = (float) currentb / 100;
                                    WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                                    layoutParams.screenBrightness = BackLightValue;
                                    getWindow().setAttributes(layoutParams);
                                    brightness.setProgress(currentb);
                                    Log.d("swipe", "up swiped");

                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            brightbool = false;
                                            hidecontrols();
                                        }
                                    },1000);
                                }
                            }

                            else if(motionEvent.getX() < (swidth / 2))
                            {
                                if (y2 > y1) {
                                    volumebool = true;
                                    hidecontrols();
                                    int f = volume.getProgress();
                                    volumeLevel = f - 5;
                                    volume.setProgress(volumeLevel);
                                    Log.d("swipe", "down swiped");

                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            volumebool = false;
                                            hidecontrols();
                                        }
                                    },1000);
                                }
                                else
                                {
                                    volumebool = true;
                                    hidecontrols();
                                    int f = volume.getProgress();
                                    volumeLevel = f + 5;

                                    volume.setProgress(volumeLevel);
                                    Log.d("swipe", "down swiped");

                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            volumebool = false;
                                            hidecontrols();
                                        }
                                    },1000);
                                }
                            }
                            mode = ExoPlayer.Mode.NONE;
                            prevDx = dx;
                            prevDy = dy;
                            break;
                        }
                }
                scaleGestureDetector.onTouchEvent(motionEvent);
                gestureDetectorCompat.onTouchEvent(motionEvent);
                brightness.onTouchEvent(motionEvent);
                if ((mode == ExoPlayer.Mode.DRAG && scale >= MIN_ZOOM) || mode == ExoPlayer.Mode.ZOOM) {
                    rlvideo.requestDisallowInterceptTouchEvent(true);
                    float maxDx = (child().getWidth() - (child().getWidth() / scale)) / 2 * scale;
                    float maxDy = (child().getHeight() - (child().getHeight() / scale)) / 2 * scale;
                    dx = Math.min(Math.max(dx, -maxDx), maxDx);
                    dy = Math.min(Math.max(dy, -maxDy), maxDy);
                    applyScaleAndTranslation();
                }
                return true;
            }
        });

        Intent intent = getIntent();
        videopath = intent.getStringExtra("videopath");
        videoname = intent.getStringExtra("videoname");

        videonameTV.setText(videoname);

        MediaItem mediaItem = MediaItem.fromUri(videopath);
        exoPlayer.addMediaItem(mediaItem);

        exoPlayer.prepare();
        exoPlayer.play();

        scaleGestureDetector = new ScaleGestureDetector(ExoPlayer.this,ExoPlayer.this);
        gestureDetectorCompat = new GestureDetectorCompat(ExoPlayer.this, new ExoPlayer.GestureDetector());

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        volume.setMaxValue(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        volumeLevel = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        volume.setProgress(volumeLevel);

        volume.setOnProgressChangeListener(new Function1<Integer, Unit>() {
            @Override
            public Unit invoke(Integer integer) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, integer, 0);
                return null;
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                exoPlayer.stop();
            }
        });

        cast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startActivity(new Intent("android.settings.WIFI_DISPLAY_SETTINGS"));
                } catch (ActivityNotFoundException e) {
                    e.printStackTrace();
                    try {
                        startActivity(new Intent("com.samsung.wfd.LAUNCH_WFD_PICKER_DLG"));
                    } catch (Exception e2) {
                        try {
                            startActivity(new Intent("android.settings.CAST_SETTINGS"));
                        } catch (Exception e3) {
                            Toast.makeText(getApplicationContext(), "Device not supported", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
        });

        bright = Settings.System.getInt(getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS, 0);
        brightness.setProgress(bright);
        brightness.setOnProgressChangeListener(new Function1<Integer, Unit>() {
            @Override
            public Unit invoke(Integer integer) {
//                Settings.System.putInt(getContentResolver(),
//                        Settings.System.SCREEN_BRIGHTNESS, integer);

                float BackLightValue = (float)integer/100;

                WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                layoutParams.screenBrightness = BackLightValue;
                getWindow().setAttributes(layoutParams);
                return null;
            }
        });

        display = getWindowManager().getDefaultDisplay();
        size = new Point();
        display.getSize(size);
        swidth = size.x;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        device_width = displayMetrics.widthPixels;
        rlvideo.setOnTouchListener(this);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            pictureInPictureParams = new PictureInPictureParams.Builder();
        }

        picin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pictureInPictureMode();
            }
        });

        fullscreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                exitscreen.setVisibility(View.VISIBLE);
                fullscreen.setVisibility(View.GONE);
            }
        });

        exitscreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exitscreen.setVisibility(View.GONE);
                fullscreen.setVisibility(View.VISIBLE);

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            exitscreen.setVisibility(View.VISIBLE);
            fullscreen.setVisibility(View.GONE);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }


    }

    private void showcontrols() {
        rlcontrol.setVisibility(View.VISIBLE);

        final Window window = this.getWindow();
        if(window==null)
        {
            return;
        }
//        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        window.clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        View decorview = window.getDecorView();
        if(decorview!=null)
        {
            int uioption = decorview.getSystemUiVisibility();
            if(Build.VERSION.SDK_INT>=14)
            {
                uioption&= ~View.SYSTEM_UI_FLAG_LOW_PROFILE;
            }

            if(Build.VERSION.SDK_INT>=16)
            {
                uioption&= ~View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
            }

            if(Build.VERSION.SDK_INT>=19)
            {
                uioption&= ~View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            }
            decorview.setSystemUiVisibility(uioption);
        }
    }

    private void hidecontrols() {
        rlcontrol.setVisibility(View.GONE);

        if(volumebool == true)
        {
            volumelayout.setVisibility(View.VISIBLE);
            brightlayout.setVisibility(View.GONE);
        }
        else
        {
            volumelayout.setVisibility(View.GONE);
        }

        if(brightbool == true)
        {
            brightlayout.setVisibility(View.VISIBLE);
            volumelayout.setVisibility(View.GONE);
        }
        else
        {
            brightlayout.setVisibility(View.GONE);
        }

        final Window window = this.getWindow();
        if(window==null)
        {
            return;
        }

//        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        window.clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        View decorview = window.getDecorView();
        if(decorview!=null)
        {
            int uioption = decorview.getSystemUiVisibility();
            if(Build.VERSION.SDK_INT>=14)
            {
                uioption |= View.SYSTEM_UI_FLAG_LOW_PROFILE;
            }

            if(Build.VERSION.SDK_INT>=16)
            {
                uioption |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
            }

            if(Build.VERSION.SDK_INT>=19)
            {
                uioption |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            }
            decorview.setSystemUiVisibility(uioption);
        }
    }

    @Override
    public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
        scale *= scaleGestureDetector.getScaleFactor();
        scale = Math.max(0.1f, Math.min(scale, 10.0f));
        playerView.setScaleX(scale);
        playerView.setScaleY(scale);
        return true;

    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
        return false;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {

    }

    private class GestureDetector extends android.view.GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

            return super.onFling(e1, e2, velocityX, velocityY);
        }

        @Override
        public boolean onDoubleTap(MotionEvent event) {

            return super.onDoubleTap(event);
        }

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {

            if(isopen)
            {
                playerView.hideController();
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                volumelayout.setVisibility(View.GONE);
                brightlayout.setVisibility(View.GONE);
                hidecontrols();
                isopen = false;
            }
            else
            {
                playerView.showController();
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                volumelayout.setVisibility(View.VISIBLE);
                brightlayout.setVisibility(View.VISIBLE);
                showcontrols();
                isopen = true;
            }
            return super.onSingleTapConfirmed(e);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        gestureDetectorCompat.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    private void pictureInPictureMode() {

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            Rational aspectratio = new Rational(playerView.getWidth(),playerView.getHeight());
            pictureInPictureParams.setAspectRatio(aspectratio).build();
            enterPictureInPictureMode(pictureInPictureParams.build());
        }
    }


    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK)
        {
            case MotionEvent.ACTION_DOWN:
                x1 = motionEvent.getX();
                y1 = motionEvent.getY();

                hidecontrols();
                if(scale > MIN_ZOOM) {
                    mode = ExoPlayer.Mode.DRAG;
                    startX = motionEvent.getX() - prevDx;
                    startY = motionEvent.getY() - prevDy;
                }
                break;

            case MotionEvent.ACTION_POINTER_DOWN:
                mode = ExoPlayer.Mode.ZOOM;
                break;
            case MotionEvent.ACTION_POINTER_UP:
                mode = ExoPlayer.Mode.DRAG;
                break;
            case MotionEvent.ACTION_UP:
                x2 = motionEvent.getX();
                y2 = motionEvent.getY();

                float valueX = x2 - x1;
                float valueY = y2 - y1;

                if(Math.abs(valueX) > MIN_DISTANCE)
                {
                    if(x2>x1){
                        // videoView.seekTo(videoView.getCurrentPosition() + 2000);
                        Log.d("swipe","right swiped");
                    }
                    else{

                        // 3videoView.seekTo(videoView.getCurrentPosition() - 2000);
                        Log.d("swipe","left swiped");

                    }
                }
                else if(Math.abs(valueY) > MIN_DISTANCE) {
                    if (motionEvent.getX() > (swidth / 2)) {

                        if (y2 > y1) {
                            brightbool = true;
                            hidecontrols();
                            int f = brightness.getProgress();
                            currentb = f - 30;

                            float BackLightValue = (float) currentb / 100;

                            WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                            layoutParams.screenBrightness = BackLightValue;
                            getWindow().setAttributes(layoutParams);
                            brightness.setProgress(currentb);

                            Log.d("swipe", "down swiped");

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    brightbool = false;
                                    hidecontrols();
                                }
                            },1000);
                        } else {
                            brightbool = true;
                            hidecontrols();
                            int f = brightness.getProgress();
                            currentb = f + 30;

                            float BackLightValue = (float) currentb / 100;
                            WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                            layoutParams.screenBrightness = BackLightValue;
                            getWindow().setAttributes(layoutParams);
                            brightness.setProgress(currentb);
                            Log.d("swipe", "up swiped");

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    brightbool = false;
                                    hidecontrols();
                                }
                            },1000);
                        }
                    }

                    else if(motionEvent.getX() < (swidth / 2))
                    {
                        if (y2 > y1) {
                            volumebool = true;
                            hidecontrols();
                            int f = volume.getProgress();
                            volumeLevel = f - 5;
                            volume.setProgress(volumeLevel);
                            Log.d("swipe", "down swiped");

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    volumebool = false;
                                    hidecontrols();
                                }
                            },1000);
                        }
                        else
                        {
                            volumebool = true;
                            hidecontrols();
                            int f = volume.getProgress();
                            volumeLevel = f + 5;

                            volume.setProgress(volumeLevel);
                            Log.d("swipe", "down swiped");

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    volumebool = false;
                                    hidecontrols();
                                }
                            },1000);
                        }
                    }
                    mode = ExoPlayer.Mode.NONE;
                    prevDx = dx;
                    prevDy = dy;
                    break;
                }
        }
        scaleGestureDetector.onTouchEvent(motionEvent);
        gestureDetectorCompat.onTouchEvent(motionEvent);
        brightness.onTouchEvent(motionEvent);
        if ((mode == ExoPlayer.Mode.DRAG && scale >= MIN_ZOOM) || mode == ExoPlayer.Mode.ZOOM) {
            rlvideo.requestDisallowInterceptTouchEvent(true);
            float maxDx = (child().getWidth() - (child().getWidth() / scale)) / 2 * scale;
            float maxDy = (child().getHeight() - (child().getHeight() / scale)) / 2 * scale;
            dx = Math.min(Math.max(dx, -maxDx), maxDx);
            dy = Math.min(Math.max(dy, -maxDy), maxDy);
            applyScaleAndTranslation();
        }
        return true;
    }

    private void applyScaleAndTranslation() {
        child().setScaleX(scale);
        child().setScaleY(scale);
        child().setTranslationX(dx);
        child().setTranslationY(dy);
    }

    private View child() {
        return zoomLayout(0);
    }

    private View zoomLayout(int i) {
        return playerView;
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        Log.e("mode",""+isInPictureInPictureMode);
        if(isInPictureInPictureMode)
        {
            //picin.setVisibility(View.GONE);
            hidecontrols();
            rlcontrol.setVisibility(View.GONE);
            Log.e("pic","in mode1");
        }
        else {
            // picin.setVisibility(View.VISIBLE);
            hidecontrols();
            Log.e("pic","not in mode1");
        }
    }

    @Override
    public void onBackPressed() {
        exoPlayer.stop();
        super.onBackPressed();
    }
}